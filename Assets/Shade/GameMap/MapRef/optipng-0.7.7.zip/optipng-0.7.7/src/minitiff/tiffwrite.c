/*
 * tiffwrite.c
 * File output routines for minitiff.
 *
 * Copyright (C) 2006-2017 Cosmin Truta.
 *
 * minitiff is open-source software, distributed under the zlib license.
 * For conditions of distribution and use, see copyright notice in minitiff.h.
 */

#include "minitiff.h"

#if 0
#error No file writing has been implemented yet.
#endif
