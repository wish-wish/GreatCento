Field of View Example:
![](Field of View Example_http://download-codeplex.sec.s-msft.com/Download/SourceControlFileDownload.ashx?ProjectName=hexgridutilities&changeSetId=22164&itemId=475933)
