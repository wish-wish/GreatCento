
# Field-of-View of 5' observer with 400 yd hexes & 30' contours

![](FOV with Curved Earth w/ 400 yd hexes & 30 ft contours_EarthCurvatureFOV.PNG)

Note the bowl effect seen by the riverside observer (red-highlighted hexagon).  
Highlighted are hexes on which a 5' tall target (or actual terrain, if higher) would just be seen above horizon.  

