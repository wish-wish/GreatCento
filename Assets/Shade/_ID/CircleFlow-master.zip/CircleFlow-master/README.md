CircleFlow
----------
CircleFlow is a project that revises Coverflow effect. Use Core Animation to build Coverflow-like effect but with a half-circle path.


## How to operate

CircleFlow view will take one swipe at a time to have one page turn. It is not like traditional Coverflow with multiple pages change at once.

## Who use it
### [Family Mart](https://itunes.apple.com/tw/app/familymart/id431477571?mt=8)
![Screenshot](https://raw.github.com/derekli66/CircleFlow/master/FamilyMartAppIcon.png)
# ![Screenshot](https://raw.github.com/derekli66/CircleFlow/master/familymarkcircleflow.gif)


Copyright: The Family Mart App icon is the trade mark belonged to Taiwan Familymart Co., LTD.

