//
//  DKAppDelegate.h
//  CircleFlow
//
//  Created by CHIEN-MING LEE on 8/1/12.
//  Copyright (c) 2012 CHIEN-MING LEE. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DKViewController;

@interface DKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) DKViewController *viewController;

@end
