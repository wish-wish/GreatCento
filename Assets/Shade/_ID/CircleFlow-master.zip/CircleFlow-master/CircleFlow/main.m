//
//  main.m
//  CircleFlow
//
//  Created by CHIEN-MING LEE on 8/1/12.
//  Copyright (c) 2012 CHIEN-MING LEE. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DKAppDelegate class]));
    }
}
