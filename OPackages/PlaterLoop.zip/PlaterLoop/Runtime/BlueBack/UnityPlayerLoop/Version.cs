

/**
 * Copyright (c) blueback
 * Released under the MIT License
 * @brief バージョン。自動生成。
*/


/** BlueBack.UnityPlayerLoop
*/
namespace BlueBack.UnityPlayerLoop
{
	/** Version
	*/
	public static class Version
	{
		/** packagename
		*/
		public const string packagename = "UnityPlayerLoop";

		/** packageversion
		*/
		public const string packageversion = "0.0.14";

		/** GetPackageVersion
		*/
		public static string GetPackageVersion()
		{
			return packageversion;
		}
	}
}

